package com.mosdev.restapi.repos;

import com.mosdev.restapi.domain.AfficheSources;
import org.springframework.data.repository.CrudRepository;

public interface AfficheSourcesRepo extends CrudRepository<AfficheSources, Long> {
}
